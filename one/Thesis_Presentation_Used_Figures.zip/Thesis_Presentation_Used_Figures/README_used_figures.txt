Figures used in Heykel_Khadhraoui_Master_Thesis_Presentation.pptx
Generated from the thesis ZIP supplied on 2026-09-07.

File	Original thesis source
MAIN_D_wrench.png	figures/MAIN_D_wrench.tex or .pdf
MAIN_NS_nullspace_automatic.png	figures/MAIN_NS_nullspace_automatic.tex or .pdf
compliance_lever_moment.png	figures/compliance_lever_moment.tex or .pdf
controller_block_diagram.png	figures/controller_block_diagram.tex or .pdf
controller_state_flow.png	figures/controller_state_flow.tex or .pdf
face_feature_selection.png	figures/face_feature_selection.tex or .pdf
hm-logo.png	figures/logos/hm-logo.png
leading_feature_cases.png	figures/leading_feature_cases.tex or .pdf
moment_bookkeeping.png	figures/moment_bookkeeping.tex or .pdf
phase_flow_chart.png	figures/phase_flow_chart.tex or .pdf
pose_hold_modes.png	figures/pose_hold_modes.tex or .pdf
reference_frames.png	figures/reference_frames.tex or .pdf
results_case_a_bars.png	figures/results_case_a_bars.tex or .pdf
results_case_b_stiffness.png	figures/results_case_b_stiffness.tex or .pdf
results_case_c_stiffness.png	figures/results_case_c_stiffness.tex or .pdf
results_case_d_panels.png	figures/results_case_d_panels.tex or .pdf
rotation_sign_convention.png	figures/rotation_sign_convention.tex or .pdf
setup_schematic.png	figures/setup_schematic.tex or .pdf
surface_entry_concept.png	figures/surface_entry_concept.tex or .pdf
surface_reference_geometry.png	figures/surface_reference_geometry.tex or .pdf
tool_clearance_criterion.png	figures/tool_clearance_criterion.tex or .pdf
